package com.booknote.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import java.awt.Font;
import java.awt.Toolkit;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JDesktopPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MainFrm extends JFrame {

	private JPanel contentPane;
	private JMenuBar menuBar;
	private CustomDesktopPane desktopPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrm frame = new MainFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrm() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(MainFrm.class.getResource("/com/booknote/view/document-512x512.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 700);
		
		/// ������ â ��� ����ϱ�
		// ������ frame ������ ����
		Dimension frameSize = getSize();
		// �ڽ��� windowscreen ������ ����

		Dimension windowSize = Toolkit.getDefaultToolkit().getScreenSize();
		// ����غ��� �� ����� ��µǴ°� Ȯ���� �� �ִ�.

		System.out.println(frameSize + " " + windowSize);

		// ��: ������width-������width)/2, (������height-������height)/2

		setLocation((windowSize.width - frameSize.width) / 2,
 					(windowSize.height - frameSize.height) / 2);
		
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		setTitle("�������");
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		desktopPane = new CustomDesktopPane();
		contentPane.add(desktopPane);
		desktopPane.setProgram("Notice");
		desktopPane.display(desktopPane);
		
		JLabel lblStatusBar = new JLabel("New label");
		contentPane.add(lblStatusBar, BorderLayout.SOUTH);
		
		lblStatusBar.setFont(new Font("��������", Font.BOLD, 12));
		
		initMenu();

		JMenu mnCategoryMenu = new JMenu("�׸�(c)");
		mnCategoryMenu.setFont(new Font("��������", Font.BOLD, 12));
		mnCategoryMenu.setMnemonic('c');
		menuBar.add(mnCategoryMenu);
		
		
	}
	
	public void initMenu() {
		
		initFileMenu();
		
	}
	
	private void initFileMenu() {
		
		JMenu mnFileMenu = new JMenu("����(f)");
		mnFileMenu.setFont(new Font("��������", Font.BOLD, 12));
		mnFileMenu.setMnemonic('f');
		menuBar.add(mnFileMenu);
		
		JMenuItem mnQuit = new JMenuItem("����(q)");
		mnQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				desktopPane.setProgram("Category");
				desktopPane.display(desktopPane);
				
			}
		});
		mnQuit.setFont(new Font("��������", Font.BOLD, 12));
		mnFileMenu.add(mnQuit);
	}
	
}
