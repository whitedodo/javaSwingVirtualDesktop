package com.booknote.view;

import java.awt.Color;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

public class CustomDesktopPane extends JDesktopPane{
		
		int numFrame = 5, x = 10, y = 10;
		String program;
		
		public String getProgram() {
			return this.program;
		}
		
		public void setProgram(String program) {
			this.program = program;
		}
		
		public void display(CustomDesktopPane dp) {
			
			String frameTitle = this.getProgram();
			JInternalFrame frame = null;
			
			if ( frameTitle.equals("Notice")) {
				frame = new Notice();
				frame.setBounds(x, y, 990, 600);
			}
			else if (frameTitle.equals("Category") ) {
				frame = new Category();
				frame.setBounds(x, y, 600, 400);
			}
			
			dp.add(frame);
			dp.setBackground(new Color(220,220,220));
			
			frame.setVisible(true);
			
		}
		
}
