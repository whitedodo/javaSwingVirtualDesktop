package com.booknote.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Dimension;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private final JPanel panel = new JPanel();
	private JTextField txtEmail;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setModalExclusionType(ModalExclusionType.TOOLKIT_EXCLUDE);

		setUndecorated(true);
		setDefaultCloseOperation (WindowConstants.DO_NOTHING_ON_CLOSE);
		setType(Type.UTILITY);
		setResizable(false);
		setBounds(100, 100, 600, 410);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		panel.setBounds(0, 0, 210, 410);
		contentPane.add(panel);
		
		/// ������ â ��� ����ϱ�
		// ������ frame ������ ����
		Dimension frameSize = getSize();
		// �ڽ��� windowscreen ������ ����

		Dimension windowSize = Toolkit.getDefaultToolkit().getScreenSize();
		// ����غ��� �� ����� ��µǴ°� Ȯ���� �� �ִ�.

		System.out.println(frameSize + " " + windowSize);

		// ��: ������width-������width)/2, (������height-������height)/2

		setLocation((windowSize.width - frameSize.width) / 2,
 					(windowSize.height - frameSize.height) / 2);
		
		JLabel lblNewLabel = new JLabel("");
		panel.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(Login.class.getResource("/com/booknote/view/login.jpg")));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(222, 89, 360, 205);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblEmail = new JLabel("�̸���(E-mail)");
		lblEmail.setFont(new Font("��������", Font.BOLD, 12));
		lblEmail.setBounds(12, 34, 93, 15);
		panel_1.add(lblEmail);
		
		JLabel lblPasswd = new JLabel("��й�ȣ(Password)");
		lblPasswd.setFont(new Font("��������", Font.BOLD, 12));
		lblPasswd.setBounds(12, 61, 115, 15);
		panel_1.add(lblPasswd);
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("��������", Font.BOLD, 12));
		txtEmail.setBounds(135, 31, 213, 21);
		panel_1.add(txtEmail);
		txtEmail.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setFont(new Font("��������", Font.BOLD, 12));
		txtPassword.setBounds(135, 58, 213, 21);
		panel_1.add(txtPassword);
		
		JButton btnLogin = new JButton("�α���(Login)");
		btnLogin.setFont(new Font("��������", Font.BOLD, 12));
		btnLogin.addActionListener(loginAction());
		btnLogin.setBounds(12, 90, 159, 23);
		panel_1.add(btnLogin);
		
		JButton btnJoin = new JButton("ȸ������(Join)");
		btnJoin.setFont(new Font("��������", Font.BOLD, 12));
		btnJoin.setBounds(189, 89, 159, 23);
		panel_1.add(btnJoin);
		
		JLabel lblX = new JLabel("X");
		lblX.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		lblX.setFont(new Font("��������", Font.BOLD, 20));
		lblX.setBackground(Color.PINK);
		lblX.setBounds(577, 10, 15, 28);
		contentPane.add(lblX);
		
	}
	
	public ActionListener loginAction() {

		ActionListener action = new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				
				Map<String, String> member = new HashMap();
				
				String uEmail = txtEmail.getText();
				String uPasswd = txtPassword.getText();
				
				String tarEmail = "admin@localhost.com"; 
				String tarPasswd = "1234";
				member.put(tarEmail, tarPasswd);
				
				if ( uEmail.equals(tarEmail) ) {
					JOptionPane.showMessageDialog(null, "������ �Է��ϼ���.\n(Please enter the number.)", "�˸�(Alert)",
						JOptionPane.INFORMATION_MESSAGE);
				}
				
				
			}
			
		};
		
		return action;
	}
}
