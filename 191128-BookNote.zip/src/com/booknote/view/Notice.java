package com.booknote.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.WindowConstants;
import javax.swing.JFrame;
import javax.swing.ImageIcon;

public class Notice extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Notice frame = new Notice();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Notice() {
		setFrameIcon(new ImageIcon(Notice.class.getResource("/com/booknote/view/document-16x16.png")));
		setTitle("asdfas");
		setResizable(true);
		setMaximizable(true);
		setClosable(true);
		setBounds(100, 100, 700, 700);
	}

}
