package com.booknote.view;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;

public class Category extends JInternalFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Category frame = new Category();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Category() {
		setFrameIcon(new ImageIcon(Notice.class.getResource("/com/booknote/view/document-16x16.png")));
		setTitle("�׸� ����");
		setClosable(true);
		setBounds(100, 100, 600, 400);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("�׸��� �����ϴ� ���Դϴ�.");
		lblNewLabel.setBounds(12, 20, 57, 15);
		getContentPane().add(lblNewLabel);
		
	}
}
